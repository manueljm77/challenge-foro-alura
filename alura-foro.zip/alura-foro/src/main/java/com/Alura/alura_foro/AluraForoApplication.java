package com.Alura.alura_foro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AluraForoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AluraForoApplication.class, args);
	}

}
