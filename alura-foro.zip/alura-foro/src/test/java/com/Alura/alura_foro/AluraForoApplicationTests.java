package com.Alura.alura_foro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AluraForoApplicationTests {

	@Test
	void contextLoads() {
	}

}
